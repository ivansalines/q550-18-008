#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
PYTHON_BIN="${PYTHON_BIN:-python3.13}"
"$PYTHON_BIN" scripts/verify_sources.py
"$PYTHON_BIN" tests/test_observer_transport.py
"$PYTHON_BIN" scripts/run_audit.py
"$PYTHON_BIN" tests/test_parent_regression.py
"$PYTHON_BIN" scripts/write_output_manifest.py
"$PYTHON_BIN" scripts/pack_sendback.py
